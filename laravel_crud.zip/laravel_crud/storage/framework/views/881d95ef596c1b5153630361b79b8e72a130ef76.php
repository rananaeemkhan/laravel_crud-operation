

<?php $__env->startSection('main'); ?>

<div class="container pt-5">
    <h1>Edit category</h1>
    <div class="row">
        <div class="col-sm-4">
            <form method="POST" action="/category_update/<?php echo e($category->id); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <label for="">Title</label>
                <input type="text" name="title" class="form-control" value="<?php echo e($category->title); ?>">
                <label for="">Profile Image</label>
                <input type="file" name="profile_image" class="form-control">
                <img src="<?php echo e(asset('uploads/categories/'.$category->profile_image)); ?>"
              alt="" width="100px" height="70px">
                <div class="di">
                <button type="submit" class="btn btn-success mt-4">update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\abc\htdocs\laravel_crud\resources\views/categories/edit.blade.php ENDPATH**/ ?>