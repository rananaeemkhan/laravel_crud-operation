

<?php $__env->startSection('main'); ?>

<div class="container">
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col col-md-6"><b>category Details</b></div>
                <div class="col-md-6">
                    <a href="<?php echo e(asset('/')); ?>" class="btn btn-primary btn-sm
                    float-end">View All</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Title</b></label>
                <div class="col-sm-10">
                    <?php echo e($category->title); ?>

                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Profile Image</b></label>
                <div class="col-sm-10">
                <img src="<?php echo e(asset('uploads/categories/'.$category->profile_image)); ?>" alt="" width="100px" height="70px">
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\abc\htdocs\laravel_crud\resources\views/categories/show.blade.php ENDPATH**/ ?>