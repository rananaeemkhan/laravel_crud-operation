

<?php $__env->startSection('main'); ?>

<div class="container">
    <div class="row  mb-4 bg-light">
        <div class="col-sm-8">
        <h1 class="text-center">Categories table</h1>
        </div>
        <div class="col-sm-4 pt-3 px-5">
        <a class="btn btn-info btn-sm" href="category_create">Add Record</a>
        </div>
    </div>
    <?php if(session()->has('success')): ?>
      <div class="alert alert-info" role="alert">
        <strong><?php echo e(session()->get('success')); ?></strong>
      </div>
    <?php endif; ?>
  <table class="table table-bordered border-dark table-hover">
    <thead>
      <tr>
        <th scope="col">S.No</th>
        <th scope="col">Id</th>
        <th scope="col">Title</th>
        <th scope="col">profile image</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
          <th><?php echo e($loop->index+1); ?></th>
          <td><?php echo e($category->id); ?></td>
          <td><?php echo e($category->title); ?></td>
          <td class="text-center">
          <a target="_blank" href="<?php echo e(asset('uploads/categories/'.$category->profile_image)); ?>"><img src="<?php echo e(asset('uploads/categories/'.$category->profile_image)); ?>"
              alt="" width="100px" height="70px"></a>
          </td>
          <td>
          <a href="user_show-<?php echo e($category->id); ?>" class="btn btn-info btn-sm text-dark">Show</a>

            <a href="/category_edit/<?php echo e($category->id); ?>" class="btn btn-warning btn-sm">Edit</a>

            <a href="/category_delete/<?php echo e($category->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('are you sure you want to delete this record')">Delete</a>
          </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\abc\htdocs\laravel_crud\resources\views/categories/list.blade.php ENDPATH**/ ?>