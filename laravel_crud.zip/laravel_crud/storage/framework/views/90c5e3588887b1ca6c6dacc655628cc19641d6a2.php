

<?php $__env->startSection('main'); ?>

<div class="container pt-5">
    <h1>new category</h1>
    <div class="row">
        <div class="col-sm-4">
            <form method="POST" action="/category_store" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="">Title</label>
                <input type="text" name="title" class="form-control" value="<?php echo e(old('errors')); ?>">
                     <label for="">Profile Image</label>
                <input type="file" name="profile_image" class="form-control" />
                <!-----this code is only for walidation form and chek error---->
                <?php if($errors->has('title')): ?>
                    <p class="text-danger"><?php echo e($errors->first('title')); ?></p>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary mt-4">submit</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\abc\htdocs\laravel_crud\resources\views/categories/createform.blade.php ENDPATH**/ ?>