@extends('layout.app')

@section('main')

<div class="container pt-5">
    <h1>new category</h1>
    <div class="row">
        <div class="col-sm-4">
            <form method="POST" action="/category_store" enctype="multipart/form-data">
                @csrf
                <label for="">Title</label>
                <input type="text" name="title" class="form-control" value="{{
                     old('errors') }}">
                     <label for="">Profile Image</label>
                <input type="file" name="profile_image" class="form-control" />
                <!-----this code is only for walidation form and chek error---->
                @if($errors->has('title'))
                    <p class="text-danger">{{ $errors->first('title') }}</p>
                @endif
                <button type="submit" class="btn btn-primary mt-4">submit</button>
            </form>
        </div>
    </div>
</div>
@endsection
