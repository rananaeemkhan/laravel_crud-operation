@extends('layout.app')

@section('main')

<div class="container">
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col col-md-6"><b>category Details</b></div>
                <div class="col-md-6">
                    <a href="{{ asset('/')}}" class="btn btn-primary btn-sm
                    float-end">View All</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Title</b></label>
                <div class="col-sm-10">
                    {{ $category->title }}
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-label-form"><b>Profile Image</b></label>
                <div class="col-sm-10">
                <img src="{{ asset('uploads/categories/'.$category->profile_image) }}" alt="" width="100px" height="70px">
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
