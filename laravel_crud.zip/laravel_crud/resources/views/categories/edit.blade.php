@extends('layout.app')

@section('main')

<div class="container pt-5">
    <h1>Edit category</h1>
    <div class="row">
        <div class="col-sm-4">
            <form method="POST" action="/category_update/{{ $category->id }}" enctype="multipart/form-data">
                @csrf
                @method('put')
                <label for="">Title</label>
                <input type="text" name="title" class="form-control" value="{{ $category->title }}">
                <label for="">Profile Image</label>
                <input type="file" name="profile_image" class="form-control">
                <img src="{{ asset('uploads/categories/'.$category->profile_image) }}"
              alt="" width="100px" height="70px">
                <div class="di">
                <button type="submit" class="btn btn-success mt-4">update</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
