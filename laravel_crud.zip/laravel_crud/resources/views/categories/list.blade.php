@extends('layout.app')

@section('main')

<div class="container">
    <div class="row  mb-4 bg-light">
        <div class="col-sm-8">
        <h1 class="text-center">Categories table</h1>
        </div>
        <div class="col-sm-4 pt-3 px-5">
        <a class="btn btn-info btn-sm" href="category_create">Add Record</a>
        </div>
    </div>
    @if(session()->has('success'))
      <div class="alert alert-info" role="alert">
        <strong>{{ session()->get('success') }}</strong>
      </div>
    @endif
  <table class="table table-bordered border-dark table-hover">
    <thead>
      <tr>
        <th scope="col">S.No</th>
        <th scope="col">Id</th>
        <th scope="col">Title</th>
        <th scope="col">profile image</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      @foreach($categories as $category)
          <tr>
          <th>{{ $loop->index+1 }}</th>
          <td>{{ $category->id }}</td>
          <td>{{ $category->title }}</td>
          <td class="text-center">
          <a target="_blank" href="{{ asset('uploads/categories/'.$category->profile_image) }}"><img src="{{ asset('uploads/categories/'.$category->profile_image) }}"
              alt="" width="100px" height="70px"></a>
          </td>
          <td>
          <a href="user_show-{{ $category->id }}" class="btn btn-info btn-sm text-dark">Show</a>

            <a href="/category_edit/{{ $category->id }}" class="btn btn-warning btn-sm">Edit</a>

            <a href="/category_delete/{{ $category->id }}" class="btn btn-danger btn-sm" onclick="return confirm('are you sure you want to delete this record')">Delete</a>
          </td>
          </tr>
      @endforeach
    </tbody>
  </table>
</div>
@endsection
