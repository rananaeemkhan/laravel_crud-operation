<?php

use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/', [CategoryController::class, 'index']);
// create page
Route::get('category_create', [CategoryController::class, 'create']);
// store record into database
Route::post('category_store', [CategoryController::class, 'store']);
// Show one record into database
Route::get('user_show-{id}', [CategoryController::class, 'show']);
// for Edit the record into database
Route::get('category_edit/{id}', [CategoryController::class, 'edit']);
// for update the record into database
Route::put('category_update/{id}', [CategoryController::class, 'update']);
// for Delete the record into database
Route::get('category_delete/{id}', [CategoryController::class, 'destory']);
