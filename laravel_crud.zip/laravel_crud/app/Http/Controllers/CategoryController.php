<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = category::get();
        // categories name stord variable $categories to access htlm file
        return view('categories.list', ['categories' => $categories]);
    }

    // create page to show on browser to click on add category button

    public function create()
    {
        return view('categories.createform');
    }

    // insert data into database through store mathod

    public function store(Request $request)
    {
        // Form validation
        $validated = $request->validate([
            'title' => 'required|unique:categories|max:255',

        ]);
        $category = new category;

        $category->title = $request->title;
        // this code is only for image
        if ($request->hasfile('profile_image')) {
            $file = $request->file('profile_image');
            $extention = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extention;
            // file path in public folder/uploads/categories
            $file->move('uploads/categories/', $filename);
            $category->profile_image = $filename;
        }
        $category->save();
        return redirect('/')->withSuccess('New Record Submit successfully..');
    }

    public function show(Request $request, $id)
    {

        $category = Category::where('id', $id)->first();
        return view('categories.show', ['category' => $category]);
    }

    public function edit($id)
    {
        $category = Category::where('id', $id)->first();
        return view('categories.edit', ['category' => $category]);
    }

    public function update(Request $request, $id)
    {

        $category = Category::where('id', $id)->first();

        $category->title = $request->title;

        if ($request->hasfile('profile_image')) {

            $destination = 'uploads/categories/' . $category->profile_image;
            if (File::exists($destination)) {
                File::delete($destination);
            }
            $file = $request->file('profile_image');
            $extention = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extention;
            // file path in public folder/uploads/categories
            $file->move('uploads/categories/', $filename);
            $category->profile_image = $filename;
        }
        $category->save();
        return redirect('/')->withSuccess('Record Update successfully..');

    }

    public function destory($id)
    {
        $category = Category::where('id', $id)->first();
        $category->delete();

        return redirect('/')->withSuccess('Record Delete successfully..');
    }
}
